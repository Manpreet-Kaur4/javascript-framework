var express = require('express');
const app = express();
const port = 3000;

const handlebars = require('express-handlebars');

app.set('view engine', 'hbs');

app.engine('hbs', handlebars({
    layoutsDir: `${__dirname}/views/layouts`,
    extname: 'hbs',
    defaultLayout: 'index',
    partialsDir:`${__dirname}/views/partials`
}));

app.use(express.static('public'));

app.get('/', (req, res) => {
    res.render('index', {layout: 'index'});
});
app.get('/about', (req, res) => {
    res.render('aboutMe', {layout: 'aboutMe'});
});
app.get('/contact', (req, res) => {
    res.render('contactMe', {layout: 'contactMe'});
});
app.get('/projects', (req, res) => {
    res.render('projects', {layout: 'projects'});
});

app.listen(port, () =>{
    console.log('App listening to port ${port}');
});