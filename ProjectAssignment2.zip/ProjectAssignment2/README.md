## About
A Node/Express/Mongoose CRUD app to manage business listings

## How to Run
`npm start`

## Additional Features
The app enables a user to search business listings