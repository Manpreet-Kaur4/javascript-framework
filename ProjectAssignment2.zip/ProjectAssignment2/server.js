require('dotenv').config();

const express = require('express');
const exphbs = require('express-handlebars');
const cors = require('cors');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const passport = require('passport');
var GitHubStrategy = require("passport-github2").Strategy;
var LocalStrategy = require("passport-local").Strategy;
const mongoose = require('mongoose');

// Declare models
const User = require('./models/User.js');
const Business = require('./models/Business.js');

// declare express app
const app = new express();

// set up options
app.use(express.static('public'));

app.use(cors());
app.use(express.json()); 
app.use(express.urlencoded({ extended: true })); 

// set up handlebars
const hbs = exphbs.create({});

app.engine('handlebars', hbs.engine);
app.set('view engine', 'handlebars');

// set up mongoose

// Mongoose Docs: https://mongoosejs.com/docs/guide.html
const mongoUri = `mongodb+srv://${process.env.DB_USER}:${process.env.DB_PASSWORD}@cluster0.notoy.mongodb.net/myFirstDatabase?retryWrites=true&w=majority`;

mongoose.connect(mongoUri, { 
    useNewUrlParser: true, 
    useUnifiedTopology: true, 
    useCreateIndex: true,
    useFindAndModify: false,
 });

// set up passport
// Passport Documentation: http://www.passportjs.org/docs/

function ensureAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
      return next()
    }
    res.redirect("/login")
};

// serialize user info
// Passport Documentation: http://www.passportjs.org/docs/
passport.serializeUser((user, done)=>{
    done(null, user._id);
});

// deserialize user
// Passport Documentation: http://www.passportjs.org/docs/
passport.deserializeUser(function(id, done) {
    User.findById(id, (err, user) => {
        done(err, user);
    });
});
  
// use github strategy for github authentication
// Passport Documentation: http://www.passportjs.org/docs/
// Github Strategy Doumentation: https://www.npmjs.com/package/passport-github2
passport.use(
    new GitHubStrategy(
      {
        clientID: process.env.GITHUB_CLIENT_ID,
        clientSecret: process.env.GITHUB_CLIENT_SECRET,
        callbackURL: process.env.GITHUB_CALLBACK_URL
      },
      function(accessToken, refreshToken, profile, done) {
        
        User.findOne({username: profile.username}).then(docs => {
                        
            if(docs){
                return done(null, docs);
            }else{
                new User({username: profile.username, password: profile.username}).save()
                .then(docs => { 
                    return done(null, docs);
                })
                .catch((err) => console.log(`ERROR: ${err}`))
            }
        })
        .catch(err => console.log(`ERROR: ${err}`));
      }
    )
);


// for local authentication
// Passport Documentation: http://www.passportjs.org/docs/
// Passport Local Documentation: http://www.passportjs.org/packages/passport-local/
passport.use(new LocalStrategy(
    function(username, password, done) {
        User.findOne({ username: username }, function (err, user) {
        if (err) { return done(err); }
        if (!user) {
            return done(null, false, { message: 'Incorrect username.' });
        }
        if (user.password !== password) {
            return done(null, false, { message: 'Incorrect password.' });
        }

        return done(null, user);
        });
    }
));

// Set up cookie parser
app.use(cookieParser(process.env.SESSION_SECRET));

// Set up session
// Express Session Docs: https://www.npmjs.com/package/express-session
app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: true
}));

// initialize passport authenticator
app.use(passport.initialize());
app.use(passport.session());

/**
 * Routes
 */

// home page
app.get('/', (req, res, next) =>{
    res.render('index', {
        pageTitle: "Home Page",
        authenticated: req.isAuthenticated(),
    });
});

//Get single business
app.get('/business/:id/view', (req, res, next) =>{

    Business
    .findOne({_id: req.params.id}).lean()
    .then(business => {
        let pageTitle = business.business_name;
        
        res.render('business', {
            pageTitle,
            business
        });
    })
    .catch(err => console.log("ERROR :", err));
});

//browse businesses
app.get('/browse', (req, res, next) =>{
    let pageTitle = "Browse Businesses";

    Business
    .find().lean()
    .then(businesses => {
        res.render('browse', {
            pageTitle,
            businesses,
            authenticated: req.isAuthenticated(),
        });
    })
    .catch(err => console.log("ERROR :", err));
});


// search businesses
app.get('/search', (req, res, next) =>{
    let pageTitle = "Search Businesses";
    let query = req.query.query;

    if(query &&  query !== ""){
        pageTitle = `Search results for ${query}`;
    }

    Business
    .find({business_name: {$regex: '.*' + query + '.*'}}).lean()
    .then(businesses => {
        res.render('search', {
            pageTitle,
            businesses,
            query,
            authenticated: req.isAuthenticated(),
        });
    })
    .catch(err => console.log("ERROR :", err));

});

// User Dashboard
app.get('/dashboard', ensureAuthenticated, (req, res, next) =>{
    let pageTitle = "User Dashboard";

    //console.log(req.user);

    Business
    .find().lean()
    .then(businesses => {
        res.render('dashboard', {
            pageTitle,
            businesses,
            authenticated: req.isAuthenticated(),
        });
    })
    .catch(err => console.log("ERROR :", err));
});

//add business listing
app.post('/businesses/add', ensureAuthenticated, (req, res, next) =>{
    new Business({
        business_name: req.body.business_name,
        business_details: req.body.business_details,
        business_location: req.body.business_location,
        business_tel_no: req.body.business_tel_no,
        user_id: req.user._id,
    }).save()
    .then(doc => {
        return res.redirect('back');
    })
    .catch(err => console.log('ERROR:',err));
});

// update business listing
app.post('/businesses/:id/update', ensureAuthenticated, (req, res, next) =>{
    Business.findOneAndUpdate(
        {_id: req.params.id},
        {
            $set: {
                business_name: req.body.business_name,
                business_details: req.body.business_details,
                business_location: req.body.business_location,
                business_tel_no: req.body.business_tel_no
            }
        },
    )
    .then(doc => {
        return res.redirect('back');
    })
    .catch(err => console.log('ERROR:',err));
});

// delete business listing
app.post('/businesses/:id/delete', ensureAuthenticated, (req, res, next) =>{
    Business.findOneAndDelete(
        {_id: req.params.id},
    )
    .then(doc => {
        return res.redirect('back');
    })
    .catch(err => console.log('ERROR:',err));
});

// Authentication

// login
app.get('/login', (req, res, next) =>{
    if(req.isAuthenticated()){
        res.redirect('/dashboard');
    }
    
    let pageTitle = "Login";

    res.render('login', {
        pageTitle,
        authenticated: req.isAuthenticated(),
    });
});

// post login route
// Passport Documentation: http://www.passportjs.org/docs

app.post('/login', passport.authenticate("local", { failureRedirect: "/login" }), (req, res, next) =>{
    let pageTitle = "Login Post";

    res.render('login', {
        pageTitle,
        authenticated: req.isAuthenticated(),
    });
});

// Github

app.get( "/login/github", passport.authenticate("github", { scope: ["user:profile"] }), (req, res) => {

});

app.get("/login/github/callback", passport.authenticate("github", { failureRedirect: "/login" }), (req, res) => {
    res.redirect("/dashboard");
});

// register
app.get('/register', (req, res, next) =>{
    if(req.isAuthenticated()){
        res.redirect('/dashboard');
    }
    
    let pageTitle = "Register";

    res.render('register', {
        pageTitle,
        authenticated: req.isAuthenticated(),
    });
});

// post registration route

//Passport Documentation: : http:www.passportjs.org/docs/login/

app.post('/register', (req, res, next) =>{
    new User({
        username: req.body.username,
        password: req.body.password,
    }).save()
    .then(doc => {
        // login user
        req.login(doc, function(err) {
            if (err) { return next(err); }
            return res.redirect('/dashboard');
        });
    })
    .catch(err => console.log('ERROR:',err));
});

// logout route

// Passport Documentation: http://www.passportjs.org/docs/logout/

app.get('/logout', (req, res, next) =>{
    req.logout();
    res.redirect('/login');
});

// set up listener
app.listen(process.env.PORT, () => { console.log(`Listening on port ${process.env.PORT}`) });
