require('dotenv').config();

const routes = require('express').Router();

const passport = require('passport');
var GitHubStrategy = require("passport-github2").Strategy;
var LocalStrategy = require("passport-local").Strategy;

const mongoose = require('mongoose');

const User = require('../models/User.js');
const Business = require('../models/Business.js');

// set up mongoose

const mongoUri = `mongodb+srv://${process.env.DB_USER}:${process.env.DB_PASSWORD}@cluster0.notoy.mongodb.net/myFirstDatabase?retryWrites=true&w=majority`;

mongoose.connect(mongoUri, { 
    useNewUrlParser: true, 
    useUnifiedTopology: true, 
    useCreateIndex: true,
    useFindAndModify: false,
 });

// const testBusiness = new Business({
//     business_name: "test business",
//     business_details: "a small business",
//     business_location: "Minseotta City, MI",
//     business_tel_no: "(123)-452-2321",
// });

// testBusiness
//     .save()
//     .then(doc => console.log(doc))
//     .catch(err => console.log("ERROR :", err));

// const users = User
//     .find()
//     .then(doc => console.log(doc))
//     .catch(err => console.log("ERROR :", err));

// set up passport

function ensureAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
      return next()
    }
    res.redirect("/login")
  }
  
  passport.serializeUser(function(user, done) {
    done(null, user)
  })
  
  passport.deserializeUser(function(obj, done) {
    done(null, obj)
  })
  
  passport.use(
    new GitHubStrategy(
      {
        clientID: process.env.GITHUB_CLIENT_ID,
        clientSecret: process.env.GITHUB_CLIENT_SECRET,
        callbackURL: process.env.GITHUB_CALLBACK_URL
      },
      function(accessToken, refreshToken, profile, done) {
        
        User.findOne({username: profile.username}).then(docs => {
                        
            if(docs){
                return done(null, docs);
            }else{
                new User({username: profile.username, password: profile.username}).save()
                .then(docs => { 
                    return done(null, docs);
                })
                .catch((err) => console.log(`ERROR: ${err}`))
            }
        })
        .catch(err => console.log(`ERROR: ${err}`));
      }
    )
  )


// initialize passport authenticator

app.use(passport.initialize());
app.use(passport.session());