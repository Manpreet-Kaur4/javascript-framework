const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const businessSchema = new Schema({
    business_name: {type: String, required: [true, "Business name is required"], unique: true},
    business_details: {type: String, required: [true, "Password is required"]},
    business_location: {type: String, required: [true, "Business location is required"]},
    business_tel_no: {type: String, required: [true, "Telephone number is required"]},
    user_id: {type: String}
});

const Business = mongoose.model('Business',businessSchema);

module.exports = Business;